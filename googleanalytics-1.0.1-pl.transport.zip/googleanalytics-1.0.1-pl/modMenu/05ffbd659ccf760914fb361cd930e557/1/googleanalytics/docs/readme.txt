----------------------
Google Analytics
----------------------
Version: 1.0.1
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------
